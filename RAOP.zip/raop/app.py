from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from twilio.rest import Client
from datetime import date
from twilio.base.exceptions import TwilioRestException

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///attendance.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Twilio configuration
account_sid = 'AC7ec0908387c4e7727ca97a1fc7934c07'
auth_token = '5fa35569d5918b8f201ccce86b05574d'
twilio_client = Client(account_sid, auth_token)

# Database models
class Teacher(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    student_id = db.Column(db.String(20), unique=True, nullable=False)
    parent_number = db.Column(db.String(15), nullable=False)
    attendances = db.relationship('Attendance', backref='student', lazy=True)

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    status = db.Column(db.String(10), nullable=False)
    date = db.Column(db.Date, nullable=False, default=date.today())
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return Teacher.query.get(int(user_id))

# Initialize the database
with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        teacher = Teacher.query.filter_by(username=username).first()
        if teacher and check_password_hash(teacher.password, password):
            login_user(teacher)
            return redirect(url_for('index'))
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_teacher = Teacher(username=username, password=hashed_password)
        db.session.add(new_teacher)
        db.session.commit()
        flash('Your account has been created!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/index')
@login_required
def index():
    return render_template('index.html')

@app.route('/add_student', methods=['POST'])
@login_required
def add_student():
    data = request.get_json()
    new_student = Student(name=data['name'], student_id=data['student_id'], parent_number=data['parent_number'])
    db.session.add(new_student)
    db.session.commit()
    return jsonify({'message': 'Student added successfully'})

@app.route('/mark_attendance', methods=['POST'])
@login_required
def mark_attendance():
    data = request.get_json()
    student = Student.query.filter_by(student_id=data['student_id']).first()
    if not student:
        return jsonify({'error': 'Student not found'}), 404

    today = date.today()
    existing_attendance = Attendance.query.filter_by(student_id=student.id, date=today).first()
    if existing_attendance:
        existing_attendance.status = data['status']
    else:
        new_attendance = Attendance(status=data['status'], date=today, student_id=student.id)
        db.session.add(new_attendance)
    db.session.commit()

    # Notify parent if absent
    if data['status'] == 'Absent':
        message = f"Your child {student.name} is absent today. Make sure to attend daily."
        try:
            twilio_client.calls.create(
                to=student.parent_number,
                from_="+19789517998",
                twiml=f"<Response><Say voice='man'>{message}</Say></Response>"
            )
        except TwilioRestException as e:
            app.logger.error(f"Twilio API error: {str(e)}")

    return jsonify({'message': 'Attendance marked successfully', 'status': data['status']})

@app.route('/get_students', methods=['GET'])
@login_required
def get_students():
    students = Student.query.all()
    student_data = []
    for student in students:
        last_attendance = Attendance.query.filter_by(student_id=student.id).order_by(Attendance.date.desc()).first()
        student_data.append({
            'name': student.name,
            'student_id': student.student_id,
            'status': last_attendance.status if last_attendance else 'N/A',
            'parent_number': student.parent_number
        })
    return jsonify(student_data)

if __name__ == '__main__':
    app.run(debug=True)
